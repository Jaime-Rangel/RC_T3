% Sistema Experto basado en Frames

:- [inferenciaHerencia].
:- [kbRedSemantica].
