% Cargar el sistema basado en conocimiento.

:- dynamic(fact/1).

:- [encadenamientoAtras].
:- [encadenamientoAdelante].
:- [explicacionesComo].
:- [kbFugasIfThen].
