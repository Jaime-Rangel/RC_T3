% Sistema Experto basado en marcos.

% :- [inferenciaMarcos].
:- [inferenciaMarcosFunc].
:- [kbMarcos].
